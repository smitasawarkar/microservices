package com.icwd.user.service.service;

import com.icwd.user.service.entities.User;

import java.util.List;

public interface UserService {

        //create
        User saveUser(User user);

       //get all users
        List<User> getAllUser();

        //get single user
        User getUser(String userId);
    }
