package com.icwd.user.service.controller;

import com.icwd.user.service.entities.User;
import com.icwd.user.service.service.UserService;
import com.icwd.user.service.service.impl.UserServiceImplsImpl;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import io.github.resilience4j.retry.annotation.Retry;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.logging.Logger;

@RestController
@RequestMapping("/user")
public class UserController {

    private org.slf4j.Logger logger = LoggerFactory.getLogger(UserController.class);
    @Autowired
    private UserService userService;
    @PostMapping("/createUser")
    public ResponseEntity<User> createUser(@RequestBody User user)
    {
        User user1 = userService.saveUser(user);
        return ResponseEntity.status(HttpStatus.CREATED).body(user1);
    }
    int retryCount=1;
    @GetMapping("/{userId}")
   // @CircuitBreaker(name="ratingHotelBreaker",fallbackMethod = "ratingHotelFallback")
    //@Retry(name="ratingHotelService",fallbackMethod = "ratingHotelFallback")
    @RateLimiter(name="userRateLimiter",fallbackMethod = "ratingHotelFallback")
    public ResponseEntity<User> getSingleUser(@PathVariable String userId)
    {
        logger.info("Get single User Handler : UserController ");
        logger.info("Retry count  :: {} ",retryCount);
        retryCount++;
        User singleUser = userService.getUser(userId);
        return ResponseEntity.ok(singleUser);
    }

    //creating fallback method
    public ResponseEntity<User> ratingHotelFallback(String UserId,Exception ex){
        logger.info("Fallback is executed bez server is down ",ex.getMessage());
        User user = User.builder().email("dummy@gmail.com").name("Dummy").about("This user is created becouse some services are down").userId("11223344").build();
        return new ResponseEntity<>(user,HttpStatus.OK);
    }
    @GetMapping("/getAllUsers")
    public ResponseEntity<List<User>> getAllUser()
    {
        List<User> allUser = userService.getAllUser();
        return ResponseEntity.ok(allUser);
    }
}
