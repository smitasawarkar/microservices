package com.icwd.user.service.service.impl;

import com.icwd.user.service.entities.Hotel;
import com.icwd.user.service.entities.Rating;
import com.icwd.user.service.entities.User;
import com.icwd.user.service.exception.ResourceNotFountException;
import com.icwd.user.service.external.services.HotelService;
import com.icwd.user.service.repository.UserRepository;
import com.icwd.user.service.service.UserService;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class UserServiceImplsImpl implements UserService {
    private org.slf4j.Logger logger = LoggerFactory.getLogger(UserServiceImplsImpl.class);
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private HotelService hotelService;
    @Override
    public User saveUser(User user) {
        String randomUniqueId = UUID.randomUUID().toString();
        user.setUserId(randomUniqueId);
        return userRepository.save(user);
    }

    @Override
    public List<User> getAllUser() {
        return userRepository.findAll();
    }

    @Override
    public User getUser(String userId) {
      User user=   userRepository.findById(userId).orElseThrow(()-> new ResourceNotFountException("User with given id is not found on server"+userId));

        Rating[] ratingsOfUser = restTemplate.getForObject("http://RATING-SERVICE/ratings/users/"+user.getUserId(), Rating[].class);
        logger.info("{} ",ratingsOfUser);

        List<Rating> ratings = Arrays.stream(ratingsOfUser).toList();
        List<Rating> ratingList= ratings.stream().map(rating -> {
            //api call to hotel service to get hotel
            //using RestTemplet
//           ResponseEntity<Hotel> forEntity = restTemplate.getForEntity("http://HOTEL-SERVICE/hotels/"+rating.getHotelId(), Hotel.class);
//            Hotel hotel = forEntity.getBody();
//            logger.info("Response status code : {} ",forEntity.getStatusCode());


            //api call using feign client
            Hotel hotel = hotelService.getHotel(rating.getHotelId());
            logger.info("get hotel details using feign client: {} ",hotel);

            //set the hotel for rating
            rating.setHotel(hotel);
            //return the rating
            return rating;
        }).collect(Collectors.toList());
        user.setRatings(ratingList);
        return user;
    }
}
