package com.icwd.user.service;

import com.icwd.user.service.entities.Rating;
import com.icwd.user.service.external.services.RatingService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserServiceApplicationTests {

	@Test
	void contextLoads() {
	}


	@Autowired
	private RatingService ratingService;

	@Test
	void createRating(){
		Rating rating = Rating.builder().rating(12).UserId("9636c2ac-3411-4eb8-828b-5c6f6d3fab21").hotelId("9003b081-62f8-493c-b262-8f56752b55d9").feedback("This is created using feing client").build();
		ratingService.createRating(rating);
		System.out.println("New rating is created");
	}


}
