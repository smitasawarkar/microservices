package com.ratings;

import com.ratings.entities.Rating;
import com.ratings.service.RatingService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.Clock;

@SpringBootTest
class RatingServiceApplicationTests {

	@Test
	void contextLoads() {
	}


}
