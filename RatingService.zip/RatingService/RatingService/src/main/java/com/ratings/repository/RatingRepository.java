package com.ratings.repository;

import com.ratings.entities.Rating;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

public interface RatingRepository extends MongoRepository<Rating,String> {

    //custom methods

    List<Rating> findRatingsByUserId(String userId);
    List<Rating> findRatingsByHotelId(String hotelId);
}
